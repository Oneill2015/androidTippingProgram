package edu.cmich.oneil2sp.tipster;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.content.Context;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;



public class MainActivity extends AppCompatActivity {
    public final static String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";
    TextView tv;
    EditText et;
    public static final String TAG = "My Activity";
    int counter = 0;
    double amount;
    Context context;
    SharedPreferences sharedPreferences;






    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = (TextView) findViewById(R.id.textView);
        et = (EditText) findViewById(R.id.editText);
        context = this.getApplicationContext();
        sharedPreferences = context.getSharedPreferences(getString(R.string.pref_file), Context.MODE_PRIVATE);

        Spinner spinner2 = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.number_people, android.R.layout.simple_spinner_item);

        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {
                // An item was selected. You can retrieve the selected item using
                // parent.getItemAtPosition(pos)
                divide(pos);

            }

            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.tip_amount, android.R.layout.simple_spinner_item);

// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {
                justTheTip(pos);


            }

            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });





    }



    public void updateTextView(View v) {
        String text =et.getText().toString();
        try {
                amount= Double.parseDouble(text);
// it means it is double
            } catch (Exception e1) {
// this means it is not double
                e1.printStackTrace();
            }
        tv = (TextView) findViewById(R.id.textView);
        tv.setText("Total: " + amount);

        return;
    }
    public void divide(int pos) {
        double value = amount/(pos + 1);
        tv = (TextView) findViewById(R.id.textView);
        tv.setText("Total: " + value);
        amount = value;

        return;
    }

    public void justTheTip(int pos) {
        double value = amount;
        if (pos ==0) {
            value = value * .05;
        } else if (pos == 1) {
            value = value * .1;
        } else if (pos == 2) {
            value = value * .15;
        } else if (pos == 3) {
            value  = value * .20;
        } else if (pos == 4) {
            value = value * .25;
        }

        tv = (TextView) findViewById(R.id.textView);
        tv.setText("Total: " + value);
        amount = value;
        return;

    }





}
